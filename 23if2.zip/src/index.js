import Phaser from "phaser-ce";

var map;
var ground;
var hero;
var cursors;

const game = new Phaser.Game(800, 600, Phaser.AUTO, "game", {
  preload: preload,
  create: create,
  update: update,
  render: render
});

function preload() {
  game.load.tilemap(
    "test",
    "./assets/test.json",
    null,
    Phaser.Tilemap.TILED_JSON
  );
  game.load.atlas(
    "hero",
    `./assets/compiled-hero.png`,
    `./assets/compiled-hero.json`,
    Phaser.Loader.TEXTURE_ATLAS_JSON_HASH
  );
  game.load.spritesheet(
    "arcade-slopes",
    `./assets/arcade-slopes-16.png`,
    16,
    16
  );
}

function create() {
  game.physics.startSystem(Phaser.Physics.ARCADE);
  game.plugins.add(Phaser.Plugin.ArcadeSlopes);
  game.slopes.preferY = true;
  game.physics.arcade.gravity.y = 1500;
  // Prefer the minimum Y offset globally
  game.slopes.preferY = true;

  //map
  map = game.add.tilemap("test");
  map.addTilesetImage("arcade-slopes");
  map.setCollisionBetween(1, 38, true);
  ground = map.createLayer("Tile Layer 1");
  game.slopes.convertTilemapLayer(ground, "arcadeslopes");

  //set world bounds
  game.world.setBounds(0, 0, map.widthInPixels, map.heightInPixels);
  game.camera.setBoundsToWorld();

  //hero
  hero = game.add.sprite(32, 32, "hero");
  game.physics.arcade.enable(this.hero);
  hero.body.bounce.y = 0.3;
  hero.body.collideWorldBounds = true;
  hero.body.setSize(
    this.hero.body.halfWidth - 10,
    this.hero.body.height - 5,
    18,
    3
  );
  hero.inputEnabled = true;
  hero.hitArea = this.hero.body.width * this.hero.body.height;
  //enable hero for slopes
  game.slopes.enable(this.hero);
  // Prefer the minimum Y offset for this physics body
  hero.body.slopes.preferY = true;
  // Pull the player into downwards collisions with a velocity of 50
  hero.body.slopes.pullDown = 50;

  //anims
  //idle
  hero.animations.add(
    "idle-right",
    Phaser.Animation.generateFrameNames("idle-right-", 0, 3, "-1.3", 2),
    2,
    true,
    false
  );
  hero.animations.add(
    "idle-left",
    Phaser.Animation.generateFrameNames("idle-left-", 0, 3, "-1.3", 2),
    2,
    true,
    false
  );
  //run
  hero.animations.add(
    "run-right",
    Phaser.Animation.generateFrameNames("run-right-", 0, 5, "-1.3", 2),
    10,
    true,
    false
  );
  hero.animations.add(
    "run-left",
    Phaser.Animation.generateFrameNames("run-left-", 0, 5, "-1.3", 2),
    10,
    true,
    false
  );
  //controls
  cursors = game.input.keyboard.createCursorKeys();
}

function update() {
  // game.physics.arcade.collide(hero, ground);
}

function render() {}
